USE logistics_operations;
SELECT DATABASE();

SELECT * 
FROM drivers_raw
LIMIT 10;

SELECT COUNT(*) 
FROM drivers_raw;

SELECT * 
FROM trucks_raw
LIMIT 10;

SELECT COUNT(*) 
FROM trucks_raw;

SELECT * 
FROM routes_raw
LIMIT 10;

SELECT COUNT(*) 
FROM routes_raw;

SELECT COUNT(*)
FROM loads_raw;

SELECT *
FROM loads_raw
LIMIT 10;

SELECT *
FROM trips_raw
LIMIT 10;

SELECT COUNT(*)
FROM trips_raw;

SELECT *
FROM fuel_purchases_raw
LIMIT 10;

SELECT COUNT(*)
FROM fuel_purchases_raw;

SELECT 'drivers_raw' AS table_name, COUNT(*) AS row_count FROM drivers_raw
UNION ALL
SELECT 'trucks_raw', COUNT(*) FROM trucks_raw
UNION ALL
SELECT 'routes_raw', COUNT(*) FROM routes_raw
UNION ALL
SELECT 'customers_raw', COUNT(*) FROM customers_raw
UNION ALL
SELECT 'loads_raw', COUNT(*) FROM loads_raw
UNION ALL
SELECT 'trips_raw', COUNT(*) FROM trips_raw
UNION ALL
SELECT 'fuel_purchases_raw', COUNT(*) FROM fuel_purchases_raw
UNION ALL
SELECT 'maintenance_records_raw', COUNT(*) FROM maintenance_records_raw;

SELECT *
FROM drivers_raw
WHERE driver_id IS NULL
   OR driver_id = '';

CREATE TABLE drivers_clean AS
SELECT
    TRIM(driver_id) AS driver_id,
    TRIM(first_name) AS first_name,
    TRIM(last_name) AS last_name,
    
    STR_TO_DATE(hire_date, '%Y-%m-%d') AS hire_date,
    
    CASE
        WHEN termination_date = '' OR termination_date IS NULL THEN NULL
        ELSE STR_TO_DATE(termination_date, '%Y-%m-%d')
    END AS termination_date,
    
    TRIM(license_number) AS license_number,
    TRIM(license_state) AS license_state,
    
    STR_TO_DATE(date_of_birth, '%Y-%m-%d') AS date_of_birth,
    
    TRIM(home_terminal) AS home_terminal,
    TRIM(employment_status) AS employment_status,
    TRIM(cdl_class) AS cdl_class,
    
    years_experience
FROM drivers_raw;

SELECT *
FROM drivers_clean
LIMIT 10;

SELECT *
FROM drivers_clean
WHERE hire_date IS NULL;

CREATE TABLE trucks_clean AS
SELECT
    TRIM(truck_id) AS truck_id,
    TRIM(unit_number) AS unit_number,
    TRIM(make) AS make,
    model_year,
    TRIM(vin) AS vin,

    STR_TO_DATE(acquisition_date, '%Y-%m-%d') AS acquisition_date,

    acquisition_mileage,
    TRIM(fuel_type) AS fuel_type,
    tank_capacity_gallons,
    TRIM(status) AS status,
    TRIM(home_terminal) AS home_terminal
FROM trucks_raw;

SELECT *
FROM trucks_clean
LIMIT 10;

SELECT *
FROM trucks_clean
WHERE acquisition_date IS NULL;

CREATE TABLE routes_clean AS
SELECT
    TRIM(route_id) AS route_id,
    TRIM(origin_city) AS origin_city,
    TRIM(origin_state) AS origin_state,
    TRIM(destination_city) AS destination_city,
    TRIM(destination_state) AS destination_state,
    typical_distance_miles,
    base_rate_per_mile,
    fuel_surcharge_rate,
    typical_transit_days
FROM routes_raw;

SELECT *
FROM routes_clean
LIMIT 10;

SELECT *
FROM routes_clean
WHERE route_id IS NULL
   OR route_id = '';
   
CREATE TABLE customers_clean AS
SELECT
    TRIM(customer_id) AS customer_id,
    TRIM(customer_name) AS customer_name,
    TRIM(customer_type) AS customer_type,
    credit_terms_days,
    TRIM(primary_freight_type) AS primary_freight_type,
    TRIM(account_status) AS account_status,

    STR_TO_DATE(contract_start_date, '%Y-%m-%d') AS contract_start_date,

    annual_revenue_potential
FROM customers_raw;

SELECT *
FROM customers_clean
LIMIT 10;

SELECT *
FROM customers_clean
WHERE contract_start_date IS NULL;

CREATE TABLE loads_clean AS
SELECT
    TRIM(load_id) AS load_id,
    TRIM(customer_id) AS customer_id,
    TRIM(route_id) AS route_id,

    STR_TO_DATE(load_date, '%Y-%m-%d') AS load_date,

    TRIM(load_type) AS load_type,
    weight_lbs,
    pieces,
    revenue,
    fuel_surcharge,
    accessorial_charges,
    TRIM(load_status) AS load_status,
    TRIM(booking_type) AS booking_type
FROM loads_raw;

SELECT *
FROM loads_clean
LIMIT 10;

SELECT *
FROM loads_clean
WHERE load_date IS NULL;

CREATE TABLE trips_clean AS
SELECT
    TRIM(trip_id) AS trip_id,
    TRIM(load_id) AS load_id,
    NULLIF(TRIM(driver_id), '') AS driver_id,
    NULLIF(TRIM(truck_id), '') AS truck_id,
    NULLIF(TRIM(trailer_id), '') AS trailer_id,

    STR_TO_DATE(dispatch_date, '%Y-%m-%d') AS dispatch_date,

    actual_distance_miles,
    actual_duration_hours,
    fuel_gallons_used,
    average_mpg,
    idle_time_hours,
    TRIM(trip_status) AS trip_status
FROM trips_raw;

SELECT *
FROM trips_clean
LIMIT 10;

SELECT *
FROM trips_clean
WHERE dispatch_date IS NULL;

SELECT
    COUNT(*) AS total_trips,
    SUM(driver_id IS NULL) AS missing_driver_id,
    SUM(truck_id IS NULL) AS missing_truck_id,
    SUM(trailer_id IS NULL) AS missing_trailer_id
FROM trips_clean;

CREATE TABLE fuel_purchases_clean AS
SELECT
    TRIM(fuel_purchase_id) AS fuel_purchase_id,
    TRIM(trip_id) AS trip_id,
    NULLIF(TRIM(truck_id), '') AS truck_id,
    NULLIF(TRIM(driver_id), '') AS driver_id,

    STR_TO_DATE(SUBSTRING_INDEX(purchase_date, ' ', 1), '%m/%d/%Y') AS purchase_date,

    TRIM(location_city) AS location_city,
    TRIM(location_state) AS location_state,

    gallons,
    price_per_gallon,
    total_cost,

    TRIM(fuel_card_number) AS fuel_card_number
FROM fuel_purchases_raw;

DROP TABLE IF EXISTS fuel_purchases_clean;

CREATE TABLE fuel_purchases_clean AS
SELECT
    TRIM(fuel_purchase_id) AS fuel_purchase_id,
    TRIM(trip_id) AS trip_id,
    NULLIF(TRIM(truck_id), '') AS truck_id,
    NULLIF(TRIM(driver_id), '') AS driver_id,

    CAST(SUBSTRING_INDEX(purchase_date, ' ', 1) AS DATE) AS purchase_date,

    TRIM(location_city) AS location_city,
    TRIM(location_state) AS location_state,

    gallons,
    price_per_gallon,
    total_cost,

    TRIM(fuel_card_number) AS fuel_card_number
FROM fuel_purchases_raw;

SELECT *
FROM fuel_purchases_clean
LIMIT 10;

SELECT *
FROM fuel_purchases_clean
WHERE purchase_date IS NULL;

CREATE TABLE maintenance_records_clean AS
SELECT
    TRIM(maintenance_id) AS maintenance_id,
    TRIM(truck_id) AS truck_id,

    STR_TO_DATE(maintenance_date, '%Y-%m-%d') AS maintenance_date,

    TRIM(maintenance_type) AS maintenance_type,

    odometer_reading,
    labor_hours,
    labor_cost,
    parts_cost,
    total_cost,

    TRIM(facility_location) AS facility_location,

    downtime_hours,

    NULLIF(TRIM(service_description), '') AS service_description
FROM maintenance_records_raw;

SELECT *
FROM maintenance_records_clean
LIMIT 10;

SELECT *
FROM maintenance_records_clean
WHERE maintenance_date IS NULL;

SELECT COUNT(*) AS missing_service_descriptions
FROM maintenance_records_clean
WHERE service_description IS NULL;

SELECT
    COUNT(*) AS total_loads,
    SUM(c.customer_id IS NULL) AS missing_customer_matches,
    SUM(r.route_id IS NULL) AS missing_route_matches
FROM loads_clean l
LEFT JOIN customers_clean c
    ON l.customer_id = c.customer_id
LEFT JOIN routes_clean r
    ON l.route_id = r.route_id;
    
SELECT
    COUNT(*) AS total_trips,
    SUM(l.load_id IS NULL) AS missing_load_matches,
    SUM(d.driver_id IS NULL) AS missing_driver_matches,
    SUM(t.truck_id IS NULL) AS missing_truck_matches
FROM trips_clean tr
LEFT JOIN loads_clean l
    ON tr.load_id = l.load_id
LEFT JOIN drivers_clean d
    ON tr.driver_id = d.driver_id
LEFT JOIN trucks_clean t
    ON tr.truck_id = t.truck_id;
    
CREATE TABLE route_profitability AS
SELECT
    r.route_id,
    r.origin_city,
    r.origin_state,
    r.destination_city,
    r.destination_state,

    COUNT(l.load_id) AS total_loads,

    SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) AS total_revenue,

    AVG(l.revenue + l.fuel_surcharge + l.accessorial_charges) AS avg_revenue_per_load,

    AVG(t.actual_distance_miles) AS avg_actual_distance,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(SUM(t.actual_distance_miles), 0),
        2
    ) AS revenue_per_mile

FROM loads_clean l
LEFT JOIN routes_clean r
    ON l.route_id = r.route_id
LEFT JOIN trips_clean t
    ON l.load_id = t.load_id

GROUP BY
    r.route_id,
    r.origin_city,
    r.origin_state,
    r.destination_city,
    r.destination_state;
    
DROP TABLE IF EXISTS route_profitability;

CREATE TABLE route_profitability AS
SELECT
    r.route_id,
    r.origin_city,
    r.origin_state,
    r.destination_city,
    r.destination_state,

    COUNT(l.load_id) AS total_loads,

    ROUND(SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS total_revenue,

    ROUND(AVG(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS avg_revenue_per_load,

    ROUND(AVG(t.actual_distance_miles), 2) AS avg_actual_distance,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(SUM(t.actual_distance_miles), 0),
        2
    ) AS revenue_per_mile

FROM loads_clean l
LEFT JOIN routes_clean r
    ON l.route_id = r.route_id
LEFT JOIN trips_clean t
    ON l.load_id = t.load_id

GROUP BY
    r.route_id,
    r.origin_city,
    r.origin_state,
    r.destination_city,
    r.destination_state;
    
SHOW WARNINGS;

SELECT *
FROM route_profitability
ORDER BY total_revenue DESC
LIMIT 10;

SELECT *
FROM route_profitability;

CREATE TABLE driver_performance AS
SELECT
    d.driver_id,
    d.first_name,
    d.last_name,
    d.home_terminal,
    d.employment_status,
    d.years_experience,

    COUNT(tr.trip_id) AS total_trips,

    ROUND(SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS total_revenue,

    ROUND(AVG(tr.average_mpg), 2) AS avg_mpg,

    ROUND(AVG(tr.idle_time_hours), 2) AS avg_idle_time,

    ROUND(AVG(tr.actual_distance_miles), 2) AS avg_trip_distance,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(COUNT(tr.trip_id), 0),
        2
    ) AS revenue_per_trip

FROM drivers_clean d
LEFT JOIN trips_clean tr
    ON d.driver_id = tr.driver_id
LEFT JOIN loads_clean l
    ON tr.load_id = l.load_id

GROUP BY
    d.driver_id,
    d.first_name,
    d.last_name,
    d.home_terminal,
    d.employment_status,
    d.years_experience;
    
SELECT *
FROM driver_performance
ORDER BY total_revenue DESC
LIMIT 10;

Select *
FROM driver_performance;

SELECT *
FROM driver_performance
ORDER BY total_revenue DESC
LIMIT 10;

SHOW WARNINGS;

CREATE TABLE truck_performance AS
SELECT
    t.truck_id,
    t.unit_number,
    t.make,
    t.model_year,
    t.fuel_type,
    t.status,
    t.home_terminal,

    COUNT(tr.trip_id) AS total_trips,

    ROUND(SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS total_revenue,

    ROUND(AVG(tr.average_mpg), 2) AS avg_mpg,

    ROUND(AVG(tr.actual_distance_miles), 2) AS avg_trip_distance,

    ROUND(SUM(m.total_cost), 2) AS total_maintenance_cost,

    ROUND(AVG(m.downtime_hours), 2) AS avg_downtime_hours,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(COUNT(tr.trip_id), 0),
        2
    ) AS revenue_per_trip

FROM trucks_clean t
LEFT JOIN trips_clean tr
    ON t.truck_id = tr.truck_id
LEFT JOIN loads_clean l
    ON tr.load_id = l.load_id
LEFT JOIN maintenance_records_clean m
    ON t.truck_id = m.truck_id

GROUP BY
    t.truck_id,
    t.unit_number,
    t.make,
    t.model_year,
    t.fuel_type,
    t.status,
    t.home_terminal;
    
DROP TABLE IF EXISTS truck_performance;

CREATE TABLE truck_maintenance_summary AS
SELECT
    truck_id,
    ROUND(SUM(total_cost), 2) AS total_maintenance_cost,
    ROUND(AVG(downtime_hours), 2) AS avg_downtime_hours
FROM maintenance_records_clean
GROUP BY truck_id;

CREATE TABLE truck_performance AS
SELECT
    t.truck_id,
    t.unit_number,
    t.make,
    t.model_year,
    t.fuel_type,
    t.status,
    t.home_terminal,

    COUNT(tr.trip_id) AS total_trips,

    ROUND(SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS total_revenue,

    ROUND(AVG(tr.average_mpg), 2) AS avg_mpg,

    ROUND(AVG(tr.actual_distance_miles), 2) AS avg_trip_distance,

    COALESCE(m.total_maintenance_cost, 0) AS total_maintenance_cost,

    COALESCE(m.avg_downtime_hours, 0) AS avg_downtime_hours,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(COUNT(tr.trip_id), 0),
        2
    ) AS revenue_per_trip

FROM trucks_clean t
LEFT JOIN trips_clean tr
    ON t.truck_id = tr.truck_id
LEFT JOIN loads_clean l
    ON tr.load_id = l.load_id
LEFT JOIN truck_maintenance_summary m
    ON t.truck_id = m.truck_id

GROUP BY
    t.truck_id,
    t.unit_number,
    t.make,
    t.model_year,
    t.fuel_type,
    t.status,
    t.home_terminal,
    m.total_maintenance_cost,
    m.avg_downtime_hours;
    
SELECT *
FROM truck_performance
ORDER BY total_revenue DESC
LIMIT 10;

SHOW WARNINGS;

SELECT *
FROM truck_performance;

CREATE TABLE customer_analysis AS
SELECT
    c.customer_id,
    c.customer_name,
    c.customer_type,
    c.primary_freight_type,
    c.account_status,
    c.credit_terms_days,
    c.annual_revenue_potential,

    COUNT(l.load_id) AS total_loads,

    ROUND(SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS total_revenue,

    ROUND(AVG(l.revenue + l.fuel_surcharge + l.accessorial_charges), 2) AS avg_revenue_per_load,

    ROUND(
        SUM(l.revenue + l.fuel_surcharge + l.accessorial_charges) /
        NULLIF(COUNT(l.load_id), 0),
        2
    ) AS revenue_per_load

FROM customers_clean c
LEFT JOIN loads_clean l
    ON c.customer_id = l.customer_id

GROUP BY
    c.customer_id,
    c.customer_name,
    c.customer_type,
    c.primary_freight_type,
    c.account_status,
    c.credit_terms_days,
    c.annual_revenue_potential;
    
SELECT *
FROM customer_analysis
ORDER BY total_revenue DESC
LIMIT 10;

SHOW WARNINGS;

SELECT *
FROM customer_analysis;

CREATE TABLE fuel_efficiency_analysis AS
SELECT
    fp.truck_id,
    t.make,
    t.model_year,
    t.home_terminal,

    COUNT(fp.fuel_purchase_id) AS total_fuel_purchases,

    ROUND(SUM(fp.gallons), 2) AS total_gallons,

    ROUND(SUM(fp.total_cost), 2) AS total_fuel_cost,

    ROUND(AVG(fp.price_per_gallon), 3) AS avg_price_per_gallon,

    ROUND(AVG(tr.average_mpg), 2) AS avg_mpg,

    ROUND(
        SUM(fp.total_cost) /
        NULLIF(SUM(fp.gallons), 0),
        3
    ) AS effective_cost_per_gallon

FROM fuel_purchases_clean fp
LEFT JOIN trucks_clean t
    ON fp.truck_id = t.truck_id
LEFT JOIN trips_clean tr
    ON fp.trip_id = tr.trip_id

GROUP BY
    fp.truck_id,
    t.make,
    t.model_year,
    t.home_terminal;
    
CREATE TABLE fuel_efficiency_analysis AS
SELECT
    fp.truck_id,
    t.make,
    t.model_year,
    t.home_terminal,

    COUNT(fp.fuel_purchase_id) AS total_fuel_purchases,

    ROUND(SUM(fp.gallons), 2) AS total_gallons,

    ROUND(SUM(fp.total_cost), 2) AS total_fuel_cost,

    ROUND(AVG(fp.price_per_gallon), 3) AS avg_price_per_gallon,

    ROUND(AVG(tr.average_mpg), 2) AS avg_mpg,

    ROUND(
        SUM(fp.total_cost) /
        NULLIF(SUM(fp.gallons), 0),
        3
    ) AS effective_cost_per_gallon

FROM fuel_purchases_clean fp
LEFT JOIN trucks_clean t
    ON fp.truck_id = t.truck_id
LEFT JOIN trips_clean tr
    ON fp.trip_id = tr.trip_id

GROUP BY
    fp.truck_id,
    t.make,
    t.model_year,
    t.home_terminal;
    
SELECT *
FROM fuel_efficiency_analysis
ORDER BY total_fuel_cost DESC
LIMIT 10;

SHOW WARNINGS;

SELECT *
FROM fuel_efficiency_analysis;

SELECT 'route_profitability' AS table_name, COUNT(*) AS row_count FROM route_profitability
UNION ALL
SELECT 'driver_performance', COUNT(*) FROM driver_performance
UNION ALL
SELECT 'truck_performance', COUNT(*) FROM truck_performance
UNION ALL
SELECT 'customer_analysis', COUNT(*) FROM customer_analysis
UNION ALL
SELECT 'fuel_efficiency_analysis', COUNT(*) FROM fuel_efficiency_analysis;

CREATE TABLE monthly_revenue_trends AS
SELECT
    DATE_FORMAT(load_date, '%Y-%m') AS revenue_month,

    COUNT(load_id) AS total_loads,

    ROUND(SUM(revenue + fuel_surcharge + accessorial_charges), 2) AS total_monthly_revenue,

    ROUND(AVG(revenue + fuel_surcharge + accessorial_charges), 2) AS avg_revenue_per_load

FROM loads_clean

GROUP BY DATE_FORMAT(load_date, '%Y-%m')

ORDER BY revenue_month;

SELECT *
FROM monthly_revenue_trends;

